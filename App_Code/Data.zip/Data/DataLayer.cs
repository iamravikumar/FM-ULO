﻿using GSA.OpenItems;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Data
{
    /// <summary>
    /// Summary description for DataAccess
    /// </summary>
    public class DataLayer : IDataLayer, IDisposable
    {
        private readonly string _connectionString;
        private readonly IZoneFinder _zoneFinder;
        private readonly DataAccess _da;

        public DataLayer(IZoneFinder zoneFinder)
        {
            _connectionString = ConfigurationManager.ConnectionStrings["DefaultConn"].ConnectionString;
            _zoneFinder = zoneFinder;
            _da = new DataAccess(_connectionString);
        }


        DataSet IAdminDataLayer.GetLoadListNotArchived()
        {
            var ds = _da.GetDataSet("spGetLoadListNotArchived");
            _da.CloseConnection();
            return ds;
        }

        DataSet IAdminDataLayer.GetLoadListWithActiveDueDate()
        {
            var ds = _da.GetDataSet("spGetLoadListWithActiveDueDate");
            _da.CloseConnection();
            return ds;
        }

        DataSet IAdminDataLayer.GetLoadDetails(string sLoadID)
        {
            var arrParams = new SqlParameter[1]; //*** always check the correct amount of parameters!***
            arrParams[0] = new SqlParameter("@LoadID", SqlDbType.Int);
            arrParams[0].Value = sLoadID;
            var ds = _da.GetDataSet("spGetLoadDetails", arrParams);
            _da.CloseConnection();
            return ds;
        }

        DataSet IAdminDataLayer.GetAllAttachmentTypes()
        {
            var ds = _da.GetDataSet("spGetDocTypes");
            _da.CloseConnection();
            return ds;
        }

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    _da.Dispose();
                    // TODO: dispose managed state (managed objects).
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~DataLayer() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        void IDisposable.Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
        }




        #endregion
    }

    //Ideally through DI, but if not, via a factory, the constructor of a base page would get a IDataLayer object
    //The inherited page could then grab an IAdmin and do it's thing
}