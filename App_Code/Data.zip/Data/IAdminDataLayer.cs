﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for IDataLayer
/// </summary>
///
namespace Data
{
    public interface IAdminDataLayer
    {
        DataSet GetLoadListNotArchived();
        DataSet GetLoadListWithActiveDueDate();
        DataSet GetLoadDetails(string sLoadID);
        DataSet GetAllAttachmentTypes();
    }
}